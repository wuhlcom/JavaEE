/** 
* @author :wuhongliang wuhongliang@zhilutec.com
* @version :2017年7月27日 上午11:17:24 * 
*/ 
package com.dazk.db.dao;
import com.dazk.common.util.UserUtilMapper;
import com.dazk.db.model.User;

public interface UserMapper extends UserUtilMapper<User> {

}
