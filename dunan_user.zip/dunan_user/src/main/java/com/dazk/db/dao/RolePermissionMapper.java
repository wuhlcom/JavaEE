package com.dazk.db.dao;

import com.dazk.common.util.RoleUtilMapper;
import com.dazk.db.model.RolePermission;

public interface RolePermissionMapper extends RoleUtilMapper<RolePermission> {
}
