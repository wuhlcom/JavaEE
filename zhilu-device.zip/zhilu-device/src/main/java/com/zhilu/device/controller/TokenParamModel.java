/** 
* @author :wuhongliang wuhongliang@zhilutec.com
* @version :2017年7月19日 下午6:58:57 *
* 接收Uri参数模板,此类只处理token 
*/
package com.zhilu.device.controller;

//解析token
public class TokenParamModel {
	private String token;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

}
