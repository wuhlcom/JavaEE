/** 
* @author :wuhongliang wuhongliang@zhilutec.com
* @version :2017年7月20日 上午11:01:12 * 
*/ 
package com.dazk.common.errcode;

public interface Result {		
	
}
