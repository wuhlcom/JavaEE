/** 
* @author :wuhongliang wuhongliang@zhilutec.com
* @version :2017年9月8日 下午5:44:41 * 
*/
package com.dazk.common.util;

public class GlobalParamsUtil {
	public final static String ADMIN_CODE = "1000000000000";
	public final static String DEFAULT_PASSWD = "123456";
	
	public final static String COMPANY_URL ="http://118.31.102.18:8081/company/queryCode";	
	public final static String TOKEN_URL ="http://118.31.102.18:9990/entry/islogin";
	
    //public final static String COMPANY_URL = "http://122.224.227.186:8736/company/queryCode";
    //public final static String TOKEN_URL = "http://122.224.227.186:8736/entry/islogin";
	
//	public final static String COMPANY_URL = "http://172.16.140.79:8081/company/queryCode";
//	public final static String TOKEN_URL = "http://172.16.140.79:9990/entry/islogin";
	
	
	
}
