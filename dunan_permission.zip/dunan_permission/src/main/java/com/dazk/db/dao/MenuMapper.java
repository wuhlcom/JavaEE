package com.dazk.db.dao;

import com.dazk.common.util.MenuUtilMapper;
import com.dazk.db.model.Menu;
//注意Menu对应的表名为resource
public interface MenuMapper extends MenuUtilMapper<Menu> {
}
