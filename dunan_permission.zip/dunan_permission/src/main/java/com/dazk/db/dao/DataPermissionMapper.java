/** 
* @author :wuhongliang wuhongliang@zhilutec.com
* @version :2017年7月28日 下午1:49:55 * 
*/ 
package com.dazk.db.dao;
import com.dazk.common.util.UserUtilMapper;
import com.dazk.db.model.DataPermission;
public interface DataPermissionMapper extends UserUtilMapper<DataPermission> {

}
