package com.dazk.db.dao;

import com.dazk.common.util.RoleUtilMapper;
import com.dazk.db.model.Role;

public interface RoleMapper extends RoleUtilMapper<Role> {
}
